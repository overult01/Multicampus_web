/**
 * 
 */

//대소문자 구분( java +javascript)
//대소문자 구분x (sql+ html)
 alert("팝업창");
 console.log("콘솔출력");
 document.write("브라우저출력<br>");
 document.write("<h1>합니다</h1>");